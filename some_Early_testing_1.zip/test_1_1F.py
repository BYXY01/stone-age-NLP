import test
from test_1_1R import ans

# test.tongji("双城记.txt")
# test.tongji("简爱.txt")
print("总字数",len(test.word_dic))

t_lst=[]
i_str=input()
i=0
for i in range(15):
    print(i+1)
    t_lst.append(ans(i_str))
    print(*t_lst[-1],sep='')
    print()

ch=''
while ans(i_str) not in t_lst:
    t_lst.append(ans(i_str))
    if ch!='q':
        ch=input()
        i+=1
        print(i+1)
        print(*t_lst[-1],sep='')
if ch=='q':
    print('...')
    print()
    print(len(t_lst))