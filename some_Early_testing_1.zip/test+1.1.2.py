import test
import random

q=11

def dfs(ch1,ch2,R_lst=[]):
    if ch1==ch2:
        return R_lst
    if ch1 in R_lst:
        return None

    t_dic_lst = sorted(test.word_dic[ch1][1].items(), key=lambda d: d[1], reverse=True)[:q]
    # print(t_dic_lst)
    for ch,t in t_dic_lst:
        # print(ch)
        if ch in '，。？！；、（）\'‘“”:：,.?!()《》—·×':
            continue
        if ch =='\n':
            continue
        t_lst=dfs(ch,ch2,[*R_lst,ch1])
        if ch2 in test.word_dic[ch1][1].keys():
            return [ch1]
        if t_lst!=None:
            return t_lst


test.tongji("../../../../Documents/双城记.txt")
test.tongji("../../../../Documents/简爱.txt")
print("总字数",len(test.word_dic))
i_str = input("请输入一些词：")

print("接下来是结果")
stack=[]
while i_str:
    while len(stack)<2:
        stack.append(i_str[0])
        i_str=i_str[1:]

    t_lst = [(),[[(stack[0],0)]],set(),{},False]
    i=0
    # while stack[1] not in t_lst[3]:
    #     if t_lst[4]:
    #         o_ch = t_lst[1][i - len(t_lst[1])][0]
    #         t_dic_lst = t_lst[1][i - len(t_lst[1])][q:]
    #     else:
    #         o_ch = t_lst[1][i][0]
    #         t_dic_lst = t_lst[1][i][:q]
    #     if i>len(t_lst[1]):
    #         t_lst[4]=True
    #         i=1
    #     for ch, t in t_dic_lst[:q]:
    #         t_lst[1].append([(ch,0),*sorted(test.word_dic[stack[0]][1].items(), key=lambda d: d[1], reverse=True)])
    #         t_lst[3][ch]=o_ch
    #         # t_lst[0].extend(t_lst[1][-1][1:q]) #???
    #     t_lst[2].add(o_ch)
    #     i+=1

    # t_lst = [stack[0]]
    # open_lst=[]
    # close=set()
    # came_from={}
    # while t_lst:
    #     t_dic_lst=sorted(test.word_dic[t_lst[0]][1].items(), key=lambda d: d[1], reverse=True)
    #     for ch,t in t_dic_lst[:q]:
    #         t_lst.append(ch)
    #     t_dic_lst=t_dic_lst[q:]
    #     close.add(t_lst.pop(0))

    print(*dfs(*stack),sep='',end='')

    stack.pop(0)
while stack:
    print(stack.pop(0),end='')

# print(t_lst[3])



# r_lst=[]
# while len(i_str)>1:
#     lch=i_str[0]
#     ch=i_str[1]
#     r_str = ""
#     word=test.word_dic[ch]
#     while True:
#         # if ch in r_str or ch in '，。；！-':
#         #     # print(ch)
#         #     break
#         if ch == '\n' :
#             break
#         if ch in i_str:
#             i_str=i_str.lstrip(ch)
#         r_str+=ch
#         ch=random.choices(list(test.word_dic[ch][1].keys()),weights=list(test.word_dic[ch][1].values()),k=1)[0]
#     r_lst.append(r_str)

# print("以下是结果：")
# for i in range(0,len(r_lst)):
#         print(r_lst[i],end='')