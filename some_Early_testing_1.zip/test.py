word_lst=[]
word_dic=dict()

def word_index(w):
    if w not in word_lst:
        word_lst.append(w)
    return word_lst.index(w)
def a_word(w):
    global last_word
    # w=word_index(w)
    if last_word:
        word=word_dic[last_word]
        word[1][w]=word[1].get(w,0)+1
        word_dic[last_word]=word
    word=word_dic.get(w,[0,{}])
    word[0]+=1
    word_dic[w]=word
    last_word=w

def tongji(filename):
    global last_word
    last_word=''
    file=open(filename,mode='r',encoding='gbk',errors='ignore')
    # for line in file:
    #     for ch in line:
    #         a_word(ch)
    a_str=file.read()
    for ch in a_str:
        a_word(ch)
    return word_dic

if __name__ == '__main__':
    tongji("../../../../Documents/双城记.txt")
    while True:
        ch=input("请输入要查找的字：")
        if ch in word_dic: print(word_dic[ch])