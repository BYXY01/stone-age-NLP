import test

test.tongji("../../../../Documents/双城记.txt")
test.tongji("../../../../Documents/简爱.txt")
# print("总字数",len(test.word_dic))
i_str = input("请输入一个字：")

r_lst=[]
for ch in i_str:
    r_str = ""
    word=test.word_dic[ch]
    while True:
        if ch in r_str or ch in '，。；！-':
            # print(ch)
            break
        if ch == '\n' :
            break
        # print(ch,end='')
        r_str+=ch
        lst = sorted(test.word_dic[ch][1].items(), key=lambda d: d[1], reverse=True)
        ch=lst[0][0]
    r_lst.append(r_str)

# for i in range(0,len(r_lst)):
#     for j in range(0,i):
#         if r_lst[i] in r_lst[j]:
#             break
#     else:
#         print(r_lst[i],end=' ')
for i in range(0,len(r_lst)):
    if r_lst[i] not in r_lst[:i]:
        print(r_lst[i],end=' ')
# print(*r_lst,sep=' ')